﻿

using _16_QuoteFinder.DataAccess;
using System.Buffers;
using System.Text.Json;
using static System.Net.WebRequestMethods;

public class QuoteFinder
{
    private readonly IWriter _writer;
    private readonly IQuotesApiDataReader _reader;
    public QuoteFinder(IWriter writer, IQuotesApiDataReader reader)
    {
        _writer = writer;
        _reader = reader;
    }

    public async void Run()
    {
        var userWord = default(string);
        var numberOfPages = default(string);
        var numberOfQuotes = default(string);
        var pagesNumber = default(int);
        var quotesNumber = default(int);
        do
        {
            _writer.WriteLine("What word are you looking for?");
            userWord = _writer.ReadLine();

            _writer.WriteLine("How many pages do you want to read?");
            numberOfPages = _writer.ReadLine();

            _writer.WriteLine("How many quotes per page?");
            numberOfQuotes = _writer.ReadLine();

            //_writer.WriteLine("Shall process pages in parallel? ('yes' or 'no')");
            //var inParallel = _writer.ReadLine();

        } while (int.TryParse(numberOfPages, out  pagesNumber) || int.TryParse(numberOfPages, out quotesNumber));
        

        for (int i = 0; i < pagesNumber; ++i)
        {
            var quotes = await GetQuotes(quotesNumber, i + 1);
            var quoteToUser = GetQuoteWithWord(userWord, quotes);
            _writer.WriteLine(quoteToUser);
        }

    }

    private string GetQuoteWithWord(string userWord, IEnumerable<Datum> quotes)
    {
        var result = default(string);

        foreach(var quote in quotes)
        {
            if(quote.quoteText.Contains(userWord))
            {
                if (result is null || quote.quoteText.Length < result.Length)
                {
                    result = quote.quoteText;
                }
            }
        }    
        if(result is null)
        {
            result = "No quote found on this page";
        }
        return result;
    }

    private async Task<IEnumerable<Datum>> GetQuotes(int limit, int page)
    {
        using var httpClient = new HttpClient();

        var endPoint = await _reader.ReadAsync(page, limit);

        HttpResponseMessage response = await httpClient.GetAsync(endPoint);
        response.EnsureSuccessStatusCode();
        string json = await response.Content.ReadAsStringAsync();

        var root = JsonSerializer.Deserialize<Root>(json);

        return root.data;
    }
}
