﻿public record Datum(
    string quoteText,
    string quoteAuthor
    );
