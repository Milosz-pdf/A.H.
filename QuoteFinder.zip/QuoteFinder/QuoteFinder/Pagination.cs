﻿public record Pagination(
    int currentPage,
    int nextPage,
    int totalPage
    );
