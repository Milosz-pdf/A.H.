﻿using _16_QuoteFinder.DataAccess.Mock;

var quoteFinder = new QuoteFinder(new consoleWriter(), new MockQuotesApiDataReader());

quoteFinder.Run();