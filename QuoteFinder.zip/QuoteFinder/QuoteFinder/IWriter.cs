﻿public interface IWriter
{
    string? ReadLine();
    void WriteLine(string input);
}