﻿public record Root(
    IReadOnlyList<Datum> data
    );