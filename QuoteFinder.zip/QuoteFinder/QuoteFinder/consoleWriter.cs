﻿internal class consoleWriter : IWriter
{
    public string? ReadLine()
    {
        return Console.ReadLine();
    }

    public void WriteLine(string input)
    {
        Console.WriteLine(input);
    }
}